package br.sp.gov.etec;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EtecApplicationTests {

	@Test
	void contextLoads() {
	}

}
