package br.sp.gov.etec.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.sp.gov.etec.entity.Aluno;

public interface AlunoRepository extends JpaRepository<Aluno, Long>{

}