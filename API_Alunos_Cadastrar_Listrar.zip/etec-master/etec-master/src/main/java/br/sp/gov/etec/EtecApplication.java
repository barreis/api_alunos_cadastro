package br.sp.gov.etec;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EtecApplication {

	public static void main(String[] args) {
		SpringApplication.run(EtecApplication.class, args);
	}

}
